//'use strict';
// //menu_left
// $('.menu_toggle').onclick(function ()=>{
//     $('.menu_left').toggleClass("open");
// })

//scroll event
/*when scrolls down, hide / when scroll up, show */
const under_menu = document.querySelector('#m_p_menu');
const html = document.querySelector('html');
console.log(html);
const x =window.innerWidth;
const y = window.innerHeight;
console.log(html.style.width);
console.log(html.style.height);

html.style.width = (`${x}px`);
html.style.height = (`${y}px`);

main_product.addEventListener('scroll', ()=>{
    let documentY = document.documentElement.scrollTop;
    let direction = documentY - window.scrollPosition >= 0 ? 1 : -1;
    window.scrollPosition = documentY; 
    console.log(direction);
    if (direction===1){
        under_menu.style.display ="";
        under_menu.style.opacity ='1';
        under_menu.style.position ='absolute';
        under_menu.style.transition = 'transform 1000ms ease-in';
        under_menu.style.transform ='translateY(-1000px)';
        } 
       else if(direction === -1){
            under_menu.style.transition = 'transform 1000ms ease-in';
            under_menu.style.transform ='translateY(500px)';
        }
})

/*footer */
const under_footer = document.querySelector('#footer');
document.addEventListener('scroll', ()=>{
    let documentf = document.documentElement.scrollTop;
    let dir1 = documentf - window.scrollPosition >= 0 ? 1 : -1;
    window.scrollPosition = documentf;
    
    if (dir1 === 1){
        under_footer.style.display ="";
        under_footer.style.opacity = '1';
        under_footer.style.position = 'absolute';
        under_footer.style.transition = 'transform 1000ms ease-in';
        under_footer.style.transform = 'translateY(500px)';
    }
})


